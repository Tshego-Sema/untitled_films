(function(){
var b=document.body;
if(document.querySelector('.lb')){
  var seen=false;try{seen=sessionStorage.getItem('uf')}catch(e){}
  if(seen){b.classList.add('skip')}
  else{setTimeout(function(){b.classList.add('opened')},1700);setTimeout(function(){b.classList.add('skip')},3500);try{sessionStorage.setItem('uf','1')}catch(e){}}
}
var m=document.getElementById('modal');if(!m)return;
var q=function(s){return m.querySelector(s)};
document.querySelectorAll('.card').forEach(function(c){
  c.addEventListener('click',function(){
    q('h2').textContent=c.dataset.title;
    q('.desc').textContent=c.dataset.desc;
    q('.role').textContent=c.dataset.role;
    q('.client').textContent=c.dataset.client;
    var p=q('.player');
    p.innerHTML=c.dataset.video?'<iframe src="'+c.dataset.video+'" allowfullscreen title="'+c.dataset.title+'"></iframe>':'Video coming soon';
    m.classList.add('open');b.style.overflow='hidden';q('.close').focus();
  });
});
function shut(){m.classList.remove('open');b.style.overflow='';q('.player').innerHTML=''}
q('.close').addEventListener('click',shut);
document.addEventListener('keydown',function(e){if(e.key==='Escape')shut()});
})();
