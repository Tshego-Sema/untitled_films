UntitledFilms website (plain HTML/CSS/JS, no build step).
Open index.html to preview. Upload the whole folder to any static host.
Edit: placeholder text in each .html file. Add images/video to /assets.
Showreel: see comment in index.html hero. Videos/thumbnails: see comment at bottom of work.html.
